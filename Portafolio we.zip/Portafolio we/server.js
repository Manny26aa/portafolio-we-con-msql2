const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const PORT = 3000;

// ----- Middlewares -----
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname)); // Sirve el HTML, CSS, etc.

// ----- Conexión a MySQL (XAMPP) -----
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',           // XAMPP por defecto va vacío
  database: 'portafolio_db',
  port: 3306
});

db.connect((err) => {
  if (err) {
    console.error('❌ Error de conexión a MySQL:', err.message);
    return;
  }
  console.log('✅ Conectado a MySQL 🟩');
});

// ----- Ruta principal -----
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'portafolio.html'));
});

// ----- Ruta que recibe el formulario -----
app.post('/registrar', (req, res) => {
  const { nombre, asunto, mensaje } = req.body;

  if (!nombre || !asunto || !mensaje) {
    return res.status(400).json({ error: 'Faltan datos obligatorios' });
  }

  const sql = 'INSERT INTO mensajes (nombre, asunto, mensaje) VALUES (?, ?, ?)';

  db.query(sql, [nombre, asunto, mensaje], (err, result) => {
    if (err) {
      console.error('❌ Error al insertar:', err.message);
      return res.status(500).json({ error: 'Error al guardar en la base de datos' });
    }   
    console.log(`📩 Nuevo mensaje guardado (ID: ${result.insertId})`);
    res.json({ ok: true, id: result.insertId });
  });
});

// ----- Iniciar servidor -----
app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});